# CCREx

CCREx is a module for predicting on protein sequences using CCREx models.

## Installation

You can install the module using pip:

```bash
pip install ccrex