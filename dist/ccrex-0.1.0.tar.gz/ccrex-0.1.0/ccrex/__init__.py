"""
CCREx package.

This package contains modules for CCREx project.
"""

from .ccrex import CCREx